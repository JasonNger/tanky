import glob
import csv

white_file_path_list = glob.glob('./train/white/*.gdl')
black_file_path_list = glob.glob('./train/black/*.gdl')

white_edge = []
black_edge = []

for white_file_path in white_file_path_list:
    node_dict = {}
    edge_list = ''
    f = open(white_file_path)
    for part in f:
        if 'node: ' in part:
            node_dict[part.split('title: ')[1].split(' ', 1)[0].strip('""')] = part.split('label: ')[1].split(' ', 1)[0].strip('""')
        if 'edge: ' in part:
            edge_list += node_dict[part.split('targetname: ')[1].split(' ', 1)[0].strip('""')]
    f.close()
    edge = ['white']
    edge.append(edge_list)
    white_edge.append(edge)

for black_file_path in black_file_path_list:
    node_dict = {}
    edge_list = ''
    f = open(black_file_path)
    for part in f:
        if 'node: ' in part:
            node_dict[part.split('title: ')[1].split(' ', 1)[0].strip('""')] = part.split('label: ')[1].split(' ', 1)[0].strip('""')
        if 'edge: ' in part:
            edge_list += node_dict[part.split('targetname: ')[1].split(' ', 1)[0].strip('""')]
    f.close()
    edge = ['black']
    edge.append(edge_list)
    black_edge.append(edge)

f1 = open('train.csv','a+',encoding='gb18030',newline='')
f2 = open('val.csv','a+',encoding='gb18030',newline='')
csv_writer1 = csv.writer(f1)
csv_writer2 = csv.writer(f2)
csv_writer1.writerow(["label","fenci"])
csv_writer2.writerow(["label","fenci"])

for i in range(len(white_edge)):
    if i % 100 != 0:
        csv_writer1.writerow(white_edge[i])
    else:
        csv_writer2.writerow(white_edge[i])
for i in range(len(black_edge)):
    if i % 100 != 0:
        csv_writer1.writerow(black_edge[i])
    else:
        csv_writer2.writerow(black_edge[i])

f1.close()
f2.close()