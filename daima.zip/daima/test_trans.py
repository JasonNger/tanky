import glob
import csv

test_file_path_list = glob.glob('./test/*.gdl')

test_edge = []

for test_file_path in test_file_path_list:
    node_dict = {}
    edge_list = []
    f = open(test_file_path)
    for part in f:
        if 'node: ' in part:
            node_dict[part.split('title: ')[1].split(' ', 1)[0].strip('""')] = part.split('label: ')[1].split(' ', 1)[0].strip('""')
        if 'edge: ' in part:
            edge_list.append(node_dict[part.split('targetname: ')[1].split(' ', 1)[0].strip('""')])
    f.close()
    edge = ['black']
    edge.append(edge_list)
    test_edge.append(edge)


f1 = open('test.csv','a+',encoding='gb18030',newline='')
csv_writer1 = csv.writer(f1)
csv_writer1.writerow(["label","fenci"])

for i in range(len(test_edge)):
    csv_writer1.writerow(test_edge[i])

f1.close()